
    //retreive values and assign to variables
        var cartCreated = localStorage.getItem("cartCreated");
        var firstSetDate = localStorage.getItem("firstSetDate");
        var firstName = localStorage.getItem( "firstname");
        var lastName = localStorage.getItem( "lastname");
        var age = localStorage.getItem( "age");
        var favProduct = localStorage.getItem( "favproduct");

    //create a new person called shopper
        var shopper = new Person(firstName,lastName,age,favProduct);


    //Person factory
    function Person(first, last, age, product) 
    {
        
        this.firstName = first;
        this.lastName = last;
        this.age = age;
        this.favoriteProductCategory = product;
    }

    //full name maker
    Person.prototype.fullName = function() 
    {
        return this.firstName + " " + this.lastName;
    };






    //utils
    //saves writing document.getElementById(eid).innerHTML = content over and over;
    function dget(eid,content)
    {
        document.getElementById(eid).innerHTML = content;
    }



    //Display stuff to the screen

    //Shows when cart was first set (incomplete)
    //dget('day', firstSetDate);

    //show shoppers full name
    dget('name', 'Welcome back '+shopper.fullName()+'!');
    //this would have been 
    //document.getElementById('name').innerHTML = 'Welcome back '+shopper.fullName()+'!'












